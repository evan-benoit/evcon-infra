import http.client
import json
import collections
from google.cloud import firestore
from google.cloud import secretmanager
from datetime import datetime
import datetime
from datetime import date
from datetime import timedelta



db = firestore.Client(project='evcon-app')


secretClient = secretmanager.SecretManagerServiceClient()
secretName = f"projects/evcon-app/secrets/football-api-key/versions/latest"
response = secretClient.access_secret_version(name=secretName)
footballAPIKey = response.payload.data.decode('UTF-8')
conn = http.client.HTTPSConnection("api-football-v1.p.rapidapi.com")

headers = {
    'X-RapidAPI-Key': footballAPIKey,
    'X-RapidAPI-Host': "api-football-v1.p.rapidapi.com"
    }


def getGamesForRequest(request):

    # I feel like I'm doing this wrong
    request_json = {'countryCode': request.get_json().get('countryCode'),
                    'leagueID': request.get_json().get('leagueID'), 
                    'seasonID': request.get_json().get('seasonID'),
                    'startDate': request.get_json().get('startDate'),
                    'endDate': request.get_json().get('endDate'),
                    'timezone': request.get_json().get('timezone')}


    getGamesForDateRange(request_json)


def getGamesForDateRange(request_json):
    # get the countryCode from the request
    countryCode = request_json['countryCode']
    # get the leagueID from the request
    leagueID = request_json['leagueID']
    # get the seasonID from the request
    season = request_json['seasonID']
    # get the startDate from the request, and convert it into a date object
    startDate = datetime.datetime.strptime(request_json['startDate'], '%Y-%m-%d').date()    
    # get the endDate from the request
    endDate = datetime.datetime.strptime(request_json['endDate'], '%Y-%m-%d').date()    
    # get the timezone from the request
    timezone = request_json['timezone']

    # create an empty array for the games
    games = []

    indexDate = startDate
    while indexDate <= endDate:
        # get the games for the date, and append them to games
        games += getGamesForDate(countryCode, leagueID, season, str(indexDate), timezone)
        # increment the date by 1 day
        indexDate = indexDate + timedelta(days=1) 

    # return a json object with the games
    return json.dumps(games) 


def getGamesForDate(countryCode, leagueID, season, date, timezone):


    # See if we have the games for that league, season, date in the database
    dateGames = db.collection("countries/" + countryCode + 
                              "/leagues/" + str(leagueID) + 
                              "/seasons/" + str(season) + 
                              "/games").document(str(date)).get() 

    # if we have the games in the database, return them unless we're querying for today
    if dateGames.exists:
        response = dateGames.to_dict()

        gamesArray = response['games']

        return gamesArray
    else:

        requestString = "/v3/fixtures?league=" + str(leagueID) + "&season=" + str(season) + "&date=" + date + "&timezone=" + timezone

        # get the games for the date
        conn.request("GET", requestString, headers=headers)

        print ("request: " + requestString)

        
        res = conn.getresponse()
        data = res.read()
        # convert the response to a json object
        data = json.loads(data.decode("utf-8"))
        # get the fixtures from the response
        response = data['response']
        # create an empty array for the games
        games = []
        # loop through the fixtures
        for fixture in response:
            homeTeam = fixture["teams"]["home"]["name"]
            awayTeam = fixture["teams"]["away"]["name"]

            print (homeTeam + " vs " + awayTeam)

            #strip the trailing W that FOOTBALL-API adds to NWSL teams.  Fuck the patriarchy!
            homeTeam = homeTeam.rstrip(' W')
            awayTeam = awayTeam.rstrip(' W')

            homeHalftimeScore = int(fixture["score"]["halftime"]["home"])
            awayHalftimeScore = int(fixture["score"]["halftime"]["away"])

            homeFinalScore = int(fixture["score"]["fulltime"]["home"])
            awayFinalScore = int(fixture["score"]["fulltime"]["away"])

            # put these variables in a dictionary
            game = {'homeTeam': homeTeam,
                    'awayTeam': awayTeam,
                    'homeHalftimeScore': homeHalftimeScore,
                    'awayHalftimeScore': awayHalftimeScore,
                    'homeFinalScore': homeFinalScore,
                    'awayFinalScore': awayFinalScore,                
            }

            games.append(game)


        data = {}
        data["games"] = games

        # cache the results in firebase, unless it's today's date (since there may still be games in progress)
        if (date != datetime.datetime.today().strftime('%Y-%m-%d')):
            print ("storing " + json.dumps(data, indent=2))

            # store the games in the firebase DB
            db.collection("countries/" + countryCode + 
                                "/leagues/" + str(leagueID) + 
                                "/seasons/" + str(season) + 
                                "/games").document(str(date)).set(data)
            
        return games
        
            


request_json = {'countryCode': 'us', 
                'leagueID': 254, 
                'seasonID': 2023, 
                'startDate': '2023-08-01', 
                'endDate': '2023-08-08', 
                'timezone': 'America/New_York'}




games = getGamesForDateRange(request_json)

print (games)

