curl -m 70 -X POST "https://us-east1-evcon-app.cloudfunctions.net/betterHalf?countryCode=us&leagueID=254&seasonID=2023&startDate=2023-07-01&endDate=2023-07-15&timezone=America/New_York"
-H "Content-Type: application/json" \
-d '{}'